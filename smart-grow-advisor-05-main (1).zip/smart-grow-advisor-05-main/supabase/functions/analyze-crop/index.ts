import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageBase64, analysisType } = await req.json();

    if (!imageBase64) {
      return new Response(
        JSON.stringify({ error: "No image provided" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = analysisType === "soil"
      ? `You are an expert agricultural soil scientist. Analyze the soil image provided and return a detailed JSON response with the following structure:
{
  "soilType": "identified soil type",
  "condition": "overall condition rating: Excellent/Good/Fair/Poor",
  "moisture": "estimated moisture level: High/Medium/Low",
  "color": "soil color description",
  "texture": "soil texture description",
  "organicMatter": "estimated organic matter content: High/Medium/Low",
  "issues": ["list of identified issues or concerns"],
  "recommendations": ["list of actionable recommendations for improvement"],
  "suitableCrops": ["list of crops suitable for this soil"],
  "fertilizerSuggestion": "recommended fertilizer type and application",
  "phEstimate": "estimated pH range based on visual analysis",
  "summary": "2-3 sentence summary of the soil condition"
}
Return ONLY valid JSON, no other text.`
      : `You are an expert agricultural scientist specializing in crop health and disease detection. Analyze the crop/plant image provided and return a detailed JSON response with the following structure:
{
  "cropIdentified": "identified crop/plant name",
  "healthStatus": "overall health: Healthy/Mild Stress/Moderate Stress/Severe Stress/Diseased",
  "confidence": "confidence percentage as number",
  "diseases": [{"name": "disease name", "severity": "Low/Medium/High", "affectedArea": "percentage estimate"}],
  "nutrientDeficiency": ["list of suspected nutrient deficiencies"],
  "pestIssues": ["list of any pest-related observations"],
  "growthStage": "estimated growth stage",
  "yieldImpact": "estimated impact on yield: None/Minor (5-10%)/Moderate (10-25%)/Severe (25-50%)/Critical (>50%)",
  "recommendations": ["list of actionable treatment and care recommendations"],
  "preventiveMeasures": ["list of preventive measures for future"],
  "irrigationAdvice": "irrigation recommendation based on plant condition",
  "harvestReadiness": "estimate of harvest readiness if applicable",
  "summary": "2-3 sentence summary of the crop condition and priority actions"
}
Return ONLY valid JSON, no other text.`;

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: systemPrompt },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: analysisType === "soil"
                    ? "Analyze this soil image in detail. Identify the soil type, condition, moisture level, and provide farming recommendations."
                    : "Analyze this crop/plant image in detail. Identify any diseases, nutrient deficiencies, pest issues, and provide treatment recommendations.",
                },
                {
                  type: "image_url",
                  image_url: { url: imageBase64 },
                },
              ],
            },
          ],
        }),
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(
        JSON.stringify({ error: "Failed to analyze image" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    // Extract JSON from the response
    let analysisResult;
    try {
      // Try to parse the content directly
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisResult = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (parseError) {
      console.error("Failed to parse AI response:", content);
      return new Response(
        JSON.stringify({ error: "Failed to parse analysis results", raw: content }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ analysis: analysisResult, analysisType }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("analyze-crop error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
