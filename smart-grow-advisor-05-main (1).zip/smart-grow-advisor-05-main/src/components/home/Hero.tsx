import { Link } from 'react-router-dom';
import { ArrowRight, BarChart3, Leaf, Droplets, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 nature-pattern" />
      <div className="absolute top-20 right-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse-slow" />
      
      {/* Floating Icons */}
      <div className="absolute top-32 right-[15%] animate-float opacity-20">
        <Leaf className="w-16 h-16 text-primary" />
      </div>
      <div className="absolute bottom-40 left-[10%] animate-float opacity-20" style={{ animationDelay: '2s' }}>
        <Droplets className="w-12 h-12 text-water" />
      </div>
      <div className="absolute top-48 left-[20%] animate-float opacity-20" style={{ animationDelay: '4s' }}>
        <Sun className="w-14 h-14 text-sun" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8 animate-fade-in">
            <BarChart3 className="w-4 h-4" />
            <span>AI-Powered Agricultural Intelligence</span>
          </div>

          {/* Main Heading */}
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold text-white drop-shadow-lg mb-6 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Predict Crop Yields with{' '}
            <span className="gradient-text drop-shadow-lg">Machine Learning</span>
          </h1>

          {/* Description */}
          <p className="text-lg md:text-xl text-white/80 drop-shadow max-w-2xl mx-auto mb-10 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Optimize farming decisions using advanced ML models. Get accurate yield predictions, 
            crop recommendations, and data-driven insights for sustainable agriculture.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <Link to="/predict">
              <Button variant="hero" size="xl" className="gap-2">
                Start Prediction
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
            <Link to="/analytics">
              <Button variant="outline" size="xl">
                View Analytics
              </Button>
            </Link>
          </div>

          {/* Stats Preview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            {[
              { label: 'Model Accuracy', value: '94%', icon: '🎯' },
              { label: 'Crops Supported', value: '6+', icon: '🌾' },
              { label: 'ML Models', value: '4', icon: '🤖' },
              { label: 'SDG Aligned', value: 'SDG-2', icon: '🌍' },
            ].map((stat, index) => (
              <div
                key={stat.label}
                className="stat-card text-center"
                style={{ animationDelay: `${0.5 + index * 0.1}s` }}
              >
                <div className="text-2xl mb-2">{stat.icon}</div>
                <div className="text-2xl md:text-3xl font-bold text-foreground mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
