import { Code, Database, Brain, Layout, Server, GitBranch } from 'lucide-react';

const technologies = [
  {
    category: 'Machine Learning',
    icon: Brain,
    items: ['XGBoost', 'Random Forest', 'Linear Regression', 'Neural Networks'],
  },
  {
    category: 'Frontend',
    icon: Layout,
    items: ['React', 'TypeScript', 'Tailwind CSS', 'Recharts'],
  },
  {
    category: 'Backend',
    icon: Server,
    items: ['Python', 'Flask/FastAPI', 'REST APIs', 'JWT Auth'],
  },
  {
    category: 'Data Processing',
    icon: Database,
    items: ['Pandas', 'NumPy', 'Scikit-learn', 'Data Preprocessing'],
  },
];

export function TechStack() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Technology Stack
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Built with industry-standard technologies for reliability, scalability, and performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {technologies.map((tech, index) => {
            const Icon = tech.icon;
            return (
              <div
                key={tech.category}
                className="text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-3">{tech.category}</h3>
                <ul className="space-y-2">
                  {tech.items.map((item) => (
                    <li key={item} className="text-sm text-muted-foreground">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Architecture Note */}
        <div className="mt-16 p-8 rounded-2xl bg-muted/50 border border-border">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <GitBranch className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">System Architecture</h4>
              <p className="text-muted-foreground text-sm">
                The system follows a modular architecture with separate frontend, backend, and ML 
                components. The ML models are trained offline and served via REST APIs. The frontend 
                provides an intuitive interface for farmers to input data and receive predictions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
