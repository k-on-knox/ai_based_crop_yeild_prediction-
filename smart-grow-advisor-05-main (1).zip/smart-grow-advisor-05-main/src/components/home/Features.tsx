import { TrendingUp, Droplets, Sprout, BarChart, Settings, Shield } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: TrendingUp,
    title: 'Yield Prediction',
    description: 'Predict crop yields using XGBoost, Random Forest, and Neural Networks with 94% accuracy.',
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
  {
    icon: Sprout,
    title: 'Crop Recommendation',
    description: 'Get AI-powered recommendations for the best crops based on soil and climate conditions.',
    color: 'text-growth',
    bg: 'bg-growth/10',
  },
  {
    icon: Droplets,
    title: 'Irrigation Optimization',
    description: 'Smart irrigation schedules based on crop water requirements and rainfall patterns.',
    color: 'text-water',
    bg: 'bg-water/10',
  },
  {
    icon: Settings,
    title: 'Fertilizer Optimization',
    description: 'Optimize N-P-K fertilizer usage to reduce costs while maximizing productivity.',
    color: 'text-soil',
    bg: 'bg-soil/10',
  },
  {
    icon: BarChart,
    title: 'Analytics Dashboard',
    description: 'Comprehensive visualizations of predictions, trends, and model performance metrics.',
    color: 'text-secondary',
    bg: 'bg-secondary/10',
  },
  {
    icon: Shield,
    title: 'Data Security',
    description: 'Secure input validation and reliable error handling for production-ready deployment.',
    color: 'text-primary',
    bg: 'bg-primary/10',
  },
];

export function Features() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
            Comprehensive Agricultural AI
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A complete decision support system powered by machine learning to optimize 
            farming operations and improve crop productivity.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={feature.title}
                className="group glass-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-xl ${feature.bg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-6 h-6 ${feature.color}`} />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
