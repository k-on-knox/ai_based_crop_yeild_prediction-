import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { historicalYields, crops } from '@/lib/mockData';
import { TrendingUp } from 'lucide-react';

export function YieldTrends() {
  return (
    <div className="space-y-6">
      {/* Historical Yield Trends */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="w-5 h-5 text-primary" />
            Historical Yield Trends (2019-2024)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={historicalYields}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="rice"
                name="Rice 🌾"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))' }}
              />
              <Line
                type="monotone"
                dataKey="wheat"
                name="Wheat 🌿"
                stroke="hsl(var(--secondary))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--secondary))' }}
              />
              <Line
                type="monotone"
                dataKey="maize"
                name="Maize 🌽"
                stroke="hsl(var(--growth))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--growth))' }}
              />
              <Line
                type="monotone"
                dataKey="cotton"
                name="Cotton ☁️"
                stroke="hsl(var(--water))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--water))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Area Chart for Cumulative Production */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Yield Distribution Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={historicalYields}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Area
                type="monotone"
                dataKey="maize"
                name="Maize"
                stackId="1"
                stroke="hsl(var(--growth))"
                fill="hsl(var(--growth) / 0.6)"
              />
              <Area
                type="monotone"
                dataKey="rice"
                name="Rice"
                stackId="1"
                stroke="hsl(var(--primary))"
                fill="hsl(var(--primary) / 0.6)"
              />
              <Area
                type="monotone"
                dataKey="wheat"
                name="Wheat"
                stackId="1"
                stroke="hsl(var(--secondary))"
                fill="hsl(var(--secondary) / 0.6)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Crop Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {crops.slice(0, 4).map((crop) => {
          const latestYield = historicalYields[historicalYields.length - 1];
          const previousYield = historicalYields[historicalYields.length - 2];
          const cropKey = crop.id as keyof typeof latestYield;
          const current = latestYield[cropKey] as number;
          const previous = previousYield[cropKey] as number;
          const growth = ((current - previous) / previous * 100).toFixed(1);

          return (
            <Card key={crop.id} className="glass-card">
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">{crop.icon}</div>
                <h4 className="font-semibold text-sm mb-1">{crop.name}</h4>
                <p className="text-2xl font-bold text-foreground">{current}</p>
                <p className="text-xs text-muted-foreground">tons/ha</p>
                <p className={`text-xs mt-2 font-medium ${Number(growth) >= 0 ? 'text-growth' : 'text-destructive'}`}>
                  {Number(growth) >= 0 ? '+' : ''}{growth}% YoY
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
