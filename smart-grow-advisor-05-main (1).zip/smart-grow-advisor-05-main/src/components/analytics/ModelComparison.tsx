import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { modelComparison } from '@/lib/mockData';
import { Trophy, Target, TrendingDown } from 'lucide-react';

export function ModelComparison() {
  const bestModel = modelComparison.reduce((best, current) => 
    current.accuracy > best.accuracy ? current : best
  );

  const radarData = modelComparison.map(model => ({
    name: model.name,
    accuracy: model.accuracy,
    r2: model.r2 * 100,
    inversermse: (1 / model.rmse) * 100,
  }));

  return (
    <div className="space-y-6">
      {/* Model Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {modelComparison.map((model) => (
          <Card
            key={model.name}
            className={`glass-card transition-all hover:shadow-lg ${
              model.name === bestModel.name ? 'ring-2 ring-primary' : ''
            }`}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-semibold text-sm">{model.name}</h3>
                {model.name === bestModel.name && (
                  <Badge className="bg-primary text-primary-foreground">
                    <Trophy className="w-3 h-3 mr-1" />
                    Best
                  </Badge>
                )}
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Target className="w-3 h-3" />
                    Accuracy
                  </span>
                  <span className="font-bold text-primary">{model.accuracy}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">R² Score</span>
                  <span className="font-medium">{model.r2}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <TrendingDown className="w-3 h-3" />
                    RMSE
                  </span>
                  <span className="font-medium">{model.rmse}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">MAE</span>
                  <span className="font-medium">{model.mae}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar Chart */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Model Accuracy Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={modelComparison} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" domain={[0, 100]} stroke="hsl(var(--muted-foreground))" />
                <YAxis dataKey="name" type="category" width={100} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="accuracy" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Radar Chart */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg">Multi-Metric Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={[
                { metric: 'Accuracy', ...Object.fromEntries(modelComparison.map(m => [m.name, m.accuracy])) },
                { metric: 'R² Score', ...Object.fromEntries(modelComparison.map(m => [m.name, m.r2 * 100])) },
                { metric: 'Precision', ...Object.fromEntries(modelComparison.map(m => [m.name, 100 - m.rmse * 10])) },
              ]}>
                <PolarGrid stroke="hsl(var(--border))" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Radar name="XGBoost" dataKey="XGBoost" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.3} />
                <Radar name="Random Forest" dataKey="Random Forest" stroke="hsl(var(--secondary))" fill="hsl(var(--secondary))" fillOpacity={0.3} />
                <Legend />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Error Metrics Table */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Detailed Error Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Model</th>
                  <th className="text-center py-3 px-4 font-semibold">RMSE ↓</th>
                  <th className="text-center py-3 px-4 font-semibold">MAE ↓</th>
                  <th className="text-center py-3 px-4 font-semibold">R² Score ↑</th>
                  <th className="text-center py-3 px-4 font-semibold">Accuracy ↑</th>
                </tr>
              </thead>
              <tbody>
                {modelComparison.map((model) => (
                  <tr key={model.name} className="border-b border-border/50 hover:bg-muted/50">
                    <td className="py-3 px-4 font-medium">{model.name}</td>
                    <td className="text-center py-3 px-4">{model.rmse}</td>
                    <td className="text-center py-3 px-4">{model.mae}</td>
                    <td className="text-center py-3 px-4">{model.r2}</td>
                    <td className="text-center py-3 px-4">
                      <Badge variant={model.accuracy >= 90 ? 'default' : 'secondary'}>
                        {model.accuracy}%
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
