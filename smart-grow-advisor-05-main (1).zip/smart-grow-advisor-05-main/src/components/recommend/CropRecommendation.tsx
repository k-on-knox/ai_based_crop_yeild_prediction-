import { useState } from 'react';
import { Thermometer, Droplets, Search, Leaf, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { crops, recommendCrop } from '@/lib/mockData';

export function CropRecommendation() {
  const [conditions, setConditions] = useState({
    temperature: 25,
    rainfall: 150,
    ph: 6.5,
  });
  const [recommendations, setRecommendations] = useState<(typeof crops[0] & { score?: number })[]>([]);
  const [searched, setSearched] = useState(false);

  const handleSearch = () => {
    const results = recommendCrop(conditions);
    setRecommendations(results);
    setSearched(true);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Panel */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5 text-primary" />
            Find Best Crops
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-destructive" />
                Temperature
              </Label>
              <span className="font-medium text-primary">{conditions.temperature}°C</span>
            </div>
            <Slider
              value={[conditions.temperature]}
              onValueChange={([v]) => setConditions(prev => ({ ...prev, temperature: v }))}
              min={5}
              max={45}
              step={1}
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-water" />
                Expected Rainfall
              </Label>
              <span className="font-medium text-primary">{conditions.rainfall} mm</span>
            </div>
            <Slider
              value={[conditions.rainfall]}
              onValueChange={([v]) => setConditions(prev => ({ ...prev, rainfall: v }))}
              min={20}
              max={400}
              step={10}
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label>Soil pH Level</Label>
              <span className="font-medium text-primary">{conditions.ph.toFixed(1)}</span>
            </div>
            <Slider
              value={[conditions.ph]}
              onValueChange={([v]) => setConditions(prev => ({ ...prev, ph: v }))}
              min={4}
              max={9}
              step={0.1}
            />
          </div>

          <Button variant="hero" className="w-full" onClick={handleSearch}>
            <Leaf className="w-5 h-5" />
            Find Recommended Crops
          </Button>
        </CardContent>
      </Card>

      {/* Results Panel */}
      <div className="space-y-4">
        <h3 className="font-display text-xl font-semibold">
          {searched ? 'Recommended Crops' : 'Enter conditions to get recommendations'}
        </h3>
        
        {searched && recommendations.length > 0 ? (
          <div className="space-y-3">
            {recommendations.map((crop, index) => (
              <Card
                key={crop.id}
                className={`glass-card transition-all hover:shadow-lg animate-fade-in ${
                  index === 0 ? 'ring-2 ring-primary' : ''
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center text-2xl">
                      {crop.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold">{crop.name}</h4>
                        {index === 0 && (
                          <Badge className="bg-primary text-primary-foreground">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Best Match
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Optimal: {crop.optimalTemp.min}-{crop.optimalTemp.max}°C, {crop.optimalRain.min}-{crop.optimalRain.max}mm
                      </p>
                      {(crop as any).category && (
                        <p className="text-xs text-muted-foreground/70 mt-0.5">{(crop as any).category}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-primary">{(crop as any).score}%</div>
                      <div className="text-xs text-muted-foreground">Match Score</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : searched ? (
          <Card className="glass-card">
            <CardContent className="p-8 text-center text-muted-foreground">
              No crops found matching your conditions
            </CardContent>
          </Card>
        ) : (
          <Card className="glass-card">
            <CardContent className="p-8 text-center">
              <Leaf className="w-12 h-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">
                Adjust the sliders and click "Find Recommended Crops" to see which crops are best suited for your conditions.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
