import { CheckCircle, AlertCircle, TrendingUp, Droplets, Calendar, FlaskConical } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { crops, type PredictionResult, type PredictionInput } from '@/lib/mockData';

interface PredictionResultProps {
  result: PredictionResult;
  input: PredictionInput;
}

export function PredictionResultCard({ result, input }: PredictionResultProps) {
  const crop = crops.find(c => c.id === input.crop);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Main Result Card */}
      <Card className="glass-card overflow-hidden">
        <div className="bg-primary/10 p-6 border-b border-border">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center text-3xl">
                {crop?.icon || '🌾'}
              </div>
              <div>
                <h2 className="font-display text-2xl font-bold text-foreground">
                  Yield Prediction
                </h2>
                <p className="text-muted-foreground">
                  {crop?.name} • {input.area} hectares
                </p>
              </div>
            </div>
            <Badge variant="secondary" className="text-sm px-3 py-1">
              Model: {result.modelUsed}
            </Badge>
          </div>
        </div>

        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Predicted Yield */}
            <div className="text-center p-6 rounded-xl bg-muted/50">
              <TrendingUp className="w-10 h-10 text-primary mx-auto mb-3" />
              <p className="text-muted-foreground mb-2">Predicted Yield</p>
              <p className="text-4xl font-bold text-foreground mb-1">
                {result.yieldPrediction.toFixed(2)}
              </p>
              <p className="text-sm text-muted-foreground">{result.unit}/hectare</p>
            </div>

            {/* Confidence Score */}
            <div className="text-center p-6 rounded-xl bg-muted/50">
              <div className="relative w-24 h-24 mx-auto mb-3">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    className="stroke-muted"
                    strokeWidth="8"
                    fill="none"
                  />
                  <circle
                    cx="48"
                    cy="48"
                    r="40"
                    className="stroke-primary"
                    strokeWidth="8"
                    fill="none"
                    strokeDasharray={`${result.confidence * 2.51} 251`}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-foreground">{result.confidence}%</span>
                </div>
              </div>
              <p className="text-muted-foreground">Prediction Confidence</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Factor Analysis */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">Factor Impact Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {result.factors.map((factor) => (
            <div key={factor.name} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{factor.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">{factor.score}%</span>
                  {factor.impact === 'positive' && (
                    <CheckCircle className="w-4 h-4 text-growth" />
                  )}
                  {factor.impact === 'negative' && (
                    <AlertCircle className="w-4 h-4 text-destructive" />
                  )}
                </div>
              </div>
              <Progress 
                value={factor.score} 
                className={`h-2 ${
                  factor.impact === 'positive' ? '[&>div]:bg-growth' : 
                  factor.impact === 'negative' ? '[&>div]:bg-destructive' : ''
                }`}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recommendations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Fertilizer Recommendation */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-soil" />
              Optimal Fertilizer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Nitrogen (N)</span>
              <Badge variant="outline">{result.optimalFertilizer.nitrogen} kg/ha</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Phosphorus (P)</span>
              <Badge variant="outline">{result.optimalFertilizer.phosphorus} kg/ha</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Potassium (K)</span>
              <Badge variant="outline">{result.optimalFertilizer.potassium} kg/ha</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Irrigation Schedule */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Droplets className="w-5 h-5 text-water" />
              Irrigation Schedule
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {result.irrigationSchedule.map((schedule, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-water mt-2 flex-shrink-0" />
                  {schedule}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Harvest Time */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="w-5 h-5 text-secondary" />
              Best Harvest Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{result.bestHarvestTime}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg">AI Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {result.recommendations.map((rec, i) => (
              <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                <CheckCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                <span className="text-sm">{rec}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
