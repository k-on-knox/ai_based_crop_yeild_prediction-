import { useState } from 'react';
import { Loader2, Leaf, Droplets, Thermometer, FlaskConical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { crops, seasons, soilTypes, type PredictionInput } from '@/lib/mockData';

// Group crops by category for the dropdown
const cropsByCategory = crops.reduce((acc, crop) => {
  const cat = (crop as any).category || 'Other';
  if (!acc[cat]) acc[cat] = [];
  acc[cat].push(crop);
  return acc;
}, {} as Record<string, typeof crops>);

interface PredictionFormProps {
  onSubmit: (data: PredictionInput) => void;
  isLoading?: boolean;
}

export function PredictionForm({ onSubmit, isLoading }: PredictionFormProps) {
  const [formData, setFormData] = useState<PredictionInput>({
    crop: '',
    season: '',
    soilType: '',
    nitrogen: 50,
    phosphorus: 30,
    potassium: 40,
    ph: 6.5,
    rainfall: 150,
    temperature: 25,
    humidity: 65,
    area: 1,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.crop || !formData.season || !formData.soilType) {
      return;
    }
    onSubmit(formData);
  };

  const updateField = <K extends keyof PredictionInput>(key: K, value: PredictionInput[K]) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Crop & Season Selection */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Leaf className="w-5 h-5 text-primary" />
            Crop & Season
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="crop">Crop Type</Label>
              <Select value={formData.crop} onValueChange={(v) => updateField('crop', v)}>
                <SelectTrigger className="input-field">
                  <SelectValue placeholder="Select crop" />
                </SelectTrigger>
                <SelectContent className="max-h-80">
                  {Object.entries(cropsByCategory).map(([category, categoryCrops]) => (
                    <SelectGroup key={category}>
                      <SelectLabel className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-2 py-1">
                        {category}
                      </SelectLabel>
                      {categoryCrops.map((crop) => (
                        <SelectItem key={crop.id} value={crop.id}>
                          <span className="flex items-center gap-2">
                            <span>{crop.icon}</span>
                            {crop.name}
                          </span>
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="season">Season</Label>
              <Select value={formData.season} onValueChange={(v) => updateField('season', v)}>
                <SelectTrigger className="input-field">
                  <SelectValue placeholder="Select season" />
                </SelectTrigger>
                <SelectContent>
                  {seasons.map((season) => (
                    <SelectItem key={season.id} value={season.id}>
                      <span className="flex flex-col">
                        <span>{season.name}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="soilType">Soil Type</Label>
              <Select value={formData.soilType} onValueChange={(v) => updateField('soilType', v)}>
                <SelectTrigger className="input-field">
                  <SelectValue placeholder="Select soil" />
                </SelectTrigger>
                <SelectContent>
                  {soilTypes.map((soil) => (
                    <SelectItem key={soil.id} value={soil.id}>
                      {soil.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="area">Cultivation Area (hectares)</Label>
            <Input
              id="area"
              type="number"
              min="0.1"
              step="0.1"
              value={formData.area}
              onChange={(e) => updateField('area', parseFloat(e.target.value) || 1)}
              className="input-field max-w-xs"
            />
          </div>
        </CardContent>
      </Card>

      {/* Soil Parameters */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FlaskConical className="w-5 h-5 text-soil" />
            Soil Parameters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between">
                <Label>Nitrogen (N)</Label>
                <span className="text-sm font-medium text-primary">{formData.nitrogen} kg/ha</span>
              </div>
              <Slider
                value={[formData.nitrogen]}
                onValueChange={([v]) => updateField('nitrogen', v)}
                min={0}
                max={140}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <Label>Phosphorus (P)</Label>
                <span className="text-sm font-medium text-primary">{formData.phosphorus} kg/ha</span>
              </div>
              <Slider
                value={[formData.phosphorus]}
                onValueChange={([v]) => updateField('phosphorus', v)}
                min={0}
                max={145}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <Label>Potassium (K)</Label>
                <span className="text-sm font-medium text-primary">{formData.potassium} kg/ha</span>
              </div>
              <Slider
                value={[formData.potassium]}
                onValueChange={([v]) => updateField('potassium', v)}
                min={0}
                max={205}
                step={1}
                className="cursor-pointer"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between">
              <Label>Soil pH</Label>
              <span className="text-sm font-medium text-primary">{formData.ph.toFixed(1)}</span>
            </div>
            <Slider
              value={[formData.ph]}
              onValueChange={([v]) => updateField('ph', v)}
              min={3.5}
              max={10}
              step={0.1}
              className="cursor-pointer"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Acidic</span>
              <span>Neutral (6.5-7.5)</span>
              <span>Alkaline</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weather Conditions */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Thermometer className="w-5 h-5 text-secondary" />
            Weather Conditions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between">
                <Label className="flex items-center gap-2">
                  <Droplets className="w-4 h-4 text-water" />
                  Rainfall
                </Label>
                <span className="text-sm font-medium text-primary">{formData.rainfall} mm</span>
              </div>
              <Slider
                value={[formData.rainfall]}
                onValueChange={([v]) => updateField('rainfall', v)}
                min={20}
                max={500}
                step={5}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <Label className="flex items-center gap-2">
                  <Thermometer className="w-4 h-4 text-destructive" />
                  Temperature
                </Label>
                <span className="text-sm font-medium text-primary">{formData.temperature}°C</span>
              </div>
              <Slider
                value={[formData.temperature]}
                onValueChange={([v]) => updateField('temperature', v)}
                min={5}
                max={50}
                step={1}
                className="cursor-pointer"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <Label>Humidity</Label>
                <span className="text-sm font-medium text-primary">{formData.humidity}%</span>
              </div>
              <Slider
                value={[formData.humidity]}
                onValueChange={([v]) => updateField('humidity', v)}
                min={10}
                max={100}
                step={1}
                className="cursor-pointer"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-center">
        <Button
          type="submit"
          variant="hero"
          size="xl"
          disabled={isLoading || !formData.crop || !formData.season || !formData.soilType}
          className="min-w-[200px]"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Predicting...
            </>
          ) : (
            <>
              Predict Yield
            </>
          )}
        </Button>
      </div>
    </form>
  );
}
