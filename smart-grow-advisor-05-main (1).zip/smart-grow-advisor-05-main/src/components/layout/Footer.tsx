import { Leaf, Github, FileText, Target } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-muted/50 border-t border-border mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Leaf className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-xl">
                Agri<span className="text-primary">Yield</span>
              </span>
            </div>
            <p className="text-muted-foreground max-w-md mb-4">
              AI-Powered Crop Yield Prediction and Optimization System. Supporting sustainable 
              agriculture through data-driven decision making.
            </p>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Target className="w-4 h-4 text-primary" />
              <span>Aligned with SDG-2: Zero Hunger</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Features</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li><Link to="/predict" className="hover:text-primary transition-colors">Yield Prediction</Link></li>
              <li><Link to="/recommend" className="hover:text-primary transition-colors">Crop Recommendations</Link></li>
              <li><Link to="/analytics" className="hover:text-primary transition-colors">Analytics Dashboard</Link></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Project Info</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span>Final Year Project</span>
              </li>
              <li className="flex items-center gap-2">
                <Github className="w-4 h-4" />
                <span>ML & AI Based</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© 2024 AgriYield - AI Crop Yield Prediction System. Engineering Major Project.</p>
        </div>
      </div>
    </footer>
  );
}
