import { useState, useEffect, useRef } from 'react';

const images = [
  '/images/slide1.jpg',
  '/images/slide2.jpg',
  '/images/slide3.jpg',
  '/images/slide4.jpg',
  '/images/slide5.jpg',
  '/images/slide6.jpg',
  '/images/slide7.jpg',
  '/images/slide8.jpg',
];

const DISPLAY_TIME = 6000; // 6s per image
const FADE_TIME = 1200; // 1.2s crossfade

export function BackgroundSlideshow() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [prevIndex, setPrevIndex] = useState<number | null>(null);
  const [fadePhase, setFadePhase] = useState<'idle' | 'fading'>('idle');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const preloaded = useRef(false);

  // Preload all images once
  useEffect(() => {
    if (preloaded.current) return;
    preloaded.current = true;
    images.forEach((src) => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  // Constant interval — never reset
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setActiveIndex((prev) => {
        const next = (prev + 1) % images.length;
        setPrevIndex(prev);
        setFadePhase('fading');

        // End fade after transition completes
        setTimeout(() => {
          setPrevIndex(null);
          setFadePhase('idle');
        }, FADE_TIME);

        return next;
      });
    }, DISPLAY_TIME);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="absolute top-0 left-0 right-0 h-[60vh] z-0 overflow-hidden" aria-hidden="true">
      {/* Previous image — fades out + zooms slightly */}
      {prevIndex !== null && (
        <div
          key={`prev-${prevIndex}`}
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(${images[prevIndex]})`,
            animation: `slideZoomOut ${FADE_TIME}ms ease-in-out forwards`,
          }}
        />
      )}

      {/* Active image — fades in + subtle Ken Burns zoom */}
      <div
        key={`active-${activeIndex}`}
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${images[activeIndex]})`,
          animation: fadePhase === 'fading'
            ? `slideZoomIn ${FADE_TIME}ms ease-in-out forwards`
            : `kenBurns ${DISPLAY_TIME}ms ease-in-out forwards`,
        }}
      />

      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-black/40" />
      {/* Gradient fade to background at bottom */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />

      {/* Inline keyframes */}
      <style>{`
        @keyframes slideZoomIn {
          0% { opacity: 0; transform: scale(1.05); }
          100% { opacity: 1; transform: scale(1); }
        }
        @keyframes slideZoomOut {
          0% { opacity: 1; transform: scale(1); }
          100% { opacity: 0; transform: scale(0.97); }
        }
        @keyframes kenBurns {
          0% { transform: scale(1); }
          100% { transform: scale(1.04); }
        }
      `}</style>
    </div>
  );
}
