import { useState, useRef, useCallback, useEffect } from 'react';
import { Camera, Upload, X, SwitchCamera, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface PhotoCaptureProps {
  onCapture: (imageBase64: string) => void;
  isAnalyzing: boolean;
}

const MAX_DIMENSION = 1024;

function resizeImage(dataUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
        const ratio = Math.min(MAX_DIMENSION / width, MAX_DIMENSION / height);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Canvas context unavailable'));
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.75));
    };
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = dataUrl;
  });
}

export function PhotoCapture({ onCapture, isAnalyzing }: PhotoCaptureProps) {
  const [mode, setMode] = useState<'idle' | 'camera' | 'preview'>('idle');
  const [preview, setPreview] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraError('Camera not supported on this device. Please upload an image instead.');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setMode('camera');
    } catch (err: any) {
      console.error('Camera error:', err);
      if (err?.name === 'NotAllowedError') {
        setCameraError('Camera permission denied. Please allow camera access or upload an image.');
      } else if (err?.name === 'NotFoundError') {
        setCameraError('No camera found. Please upload an image instead.');
      } else {
        setCameraError('Unable to access camera. Please use file upload instead.');
      }
    }
  }, [facingMode]);

  const capturePhoto = useCallback(async () => {
    if (!videoRef.current) return;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(videoRef.current, 0, 0);
      const raw = canvas.toDataURL('image/jpeg', 0.8);
      const resized = await resizeImage(raw);
      setPreview(resized);
      setMode('preview');
      stopCamera();
    } catch (err) {
      console.error('Capture error:', err);
      toast.error('Failed to capture photo. Please try again.');
    }
  }, [stopCamera]);

  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file (JPG, PNG, etc.)');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      toast.error('Image is too large. Please select an image under 20MB.');
      return;
    }

    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });

      const resized = await resizeImage(dataUrl);
      setPreview(resized);
      setMode('preview');
    } catch (err) {
      console.error('File upload error:', err);
      toast.error('Failed to process image. Please try another file.');
    }

    // Reset input so same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, []);

  const toggleFacing = useCallback(async () => {
    stopCamera();
    const next = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(next);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: next, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
    } catch (err) {
      console.error('Camera switch error:', err);
      toast.error('Failed to switch camera.');
    }
  }, [facingMode, stopCamera]);

  const reset = useCallback(() => {
    setPreview(null);
    setMode('idle');
    stopCamera();
  }, [stopCamera]);

  const handleAnalyze = useCallback(() => {
    if (preview) onCapture(preview);
  }, [preview, onCapture]);

  // Idle state
  if (mode === 'idle') {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card
          className="glass-card cursor-pointer group hover:border-primary/50 transition-all"
          onClick={startCamera}
        >
          <CardContent className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
              <Camera className="w-8 h-8 text-primary" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-foreground">Take Photo</p>
              <p className="text-sm text-muted-foreground mt-1">
                Use your camera to capture crop or soil
              </p>
            </div>
          </CardContent>
        </Card>

        <Card
          className="glass-card cursor-pointer group hover:border-primary/50 transition-all"
          onClick={() => fileInputRef.current?.click()}
        >
          <CardContent className="flex flex-col items-center justify-center py-12 gap-4">
            <div className="w-16 h-16 rounded-2xl bg-secondary/10 flex items-center justify-center group-hover:bg-secondary/20 transition-colors">
              <Upload className="w-8 h-8 text-secondary" />
            </div>
            <div className="text-center">
              <p className="font-semibold text-foreground">Upload Image</p>
              <p className="text-sm text-muted-foreground mt-1">
                Select from gallery or files
              </p>
            </div>
          </CardContent>
        </Card>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,image/*"
          className="hidden"
          onChange={handleFileUpload}
        />

        {cameraError && (
          <div className="col-span-full text-center text-sm text-destructive bg-destructive/10 rounded-lg p-3">
            {cameraError}
          </div>
        )}
      </div>
    );
  }

  // Camera mode
  if (mode === 'camera') {
    return (
      <div className="relative rounded-xl overflow-hidden bg-foreground/5">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full aspect-[4/3] object-cover"
        />

        {/* Camera overlay */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-8 border-2 border-primary-foreground/30 rounded-2xl" />
          <div className="absolute top-10 left-10 w-8 h-8 border-t-2 border-l-2 border-primary rounded-tl-lg" />
          <div className="absolute top-10 right-10 w-8 h-8 border-t-2 border-r-2 border-primary rounded-tr-lg" />
          <div className="absolute bottom-10 left-10 w-8 h-8 border-b-2 border-l-2 border-primary rounded-bl-lg" />
          <div className="absolute bottom-10 right-10 w-8 h-8 border-b-2 border-r-2 border-primary rounded-br-lg" />
        </div>

        {/* Controls */}
        <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center gap-4">
          <Button variant="outline" size="icon" onClick={reset} className="rounded-full bg-background/80 backdrop-blur">
            <X className="w-5 h-5" />
          </Button>
          <Button
            onClick={capturePhoto}
            className="w-16 h-16 rounded-full bg-primary hover:bg-primary/90 shadow-lg"
          >
            <Camera className="w-6 h-6 text-primary-foreground" />
          </Button>
          <Button variant="outline" size="icon" onClick={toggleFacing} className="rounded-full bg-background/80 backdrop-blur">
            <SwitchCamera className="w-5 h-5" />
          </Button>
        </div>
      </div>
    );
  }

  // Preview mode
  return (
    <div className="space-y-4">
      <div className="relative rounded-xl overflow-hidden">
        <img
          src={preview!}
          alt="Captured"
          className={cn("w-full aspect-[4/3] object-cover", isAnalyzing && "opacity-50")}
        />
        {isAnalyzing && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-foreground/20 backdrop-blur-sm">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
            <p className="mt-3 font-medium text-primary-foreground text-lg">Analyzing image...</p>
          </div>
        )}
      </div>
      <div className="flex gap-3 justify-center">
        <Button variant="outline" onClick={reset} disabled={isAnalyzing}>
          <X className="w-4 h-4 mr-2" /> Retake
        </Button>
        <Button variant="hero" onClick={handleAnalyze} disabled={isAnalyzing}>
          {isAnalyzing ? (
            <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Analyzing...</>
          ) : (
            '🔍 Analyze Photo'
          )}
        </Button>
      </div>
    </div>
  );
}
