import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Leaf, AlertTriangle, Droplets, Bug, TrendingDown, Sprout, ShieldCheck } from 'lucide-react';

interface CropAnalysis {
  cropIdentified: string;
  healthStatus: string;
  confidence: number;
  diseases: { name: string; severity: string; affectedArea: string }[];
  nutrientDeficiency: string[];
  pestIssues: string[];
  growthStage: string;
  yieldImpact: string;
  recommendations: string[];
  preventiveMeasures: string[];
  irrigationAdvice: string;
  harvestReadiness: string;
  summary: string;
}

const healthColors: Record<string, string> = {
  Healthy: 'bg-primary/10 text-primary border-primary/30',
  'Mild Stress': 'bg-secondary/10 text-secondary border-secondary/30',
  'Moderate Stress': 'bg-secondary/15 text-secondary border-secondary/40',
  'Severe Stress': 'bg-destructive/10 text-destructive border-destructive/30',
  Diseased: 'bg-destructive/15 text-destructive border-destructive/40',
};

export function CropAnalysisResult({ analysis }: { analysis: CropAnalysis }) {
  const statusColor = healthColors[analysis.healthStatus] || healthColors['Mild Stress'];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Summary Header */}
      <Card className="glass-card overflow-hidden">
        <div className="h-1 bg-gradient-to-r from-primary via-secondary to-primary" />
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Leaf className="w-6 h-6 text-primary" />
              {analysis.cropIdentified}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className={statusColor}>{analysis.healthStatus}</Badge>
              <Badge variant="outline">{analysis.confidence}% confidence</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{analysis.summary}</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-4">
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Growth Stage</p>
              <p className="font-medium text-sm text-foreground">{analysis.growthStage}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Yield Impact</p>
              <p className="font-medium text-sm text-foreground">{analysis.yieldImpact}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Harvest Ready</p>
              <p className="font-medium text-sm text-foreground">{analysis.harvestReadiness}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Diseases */}
      {analysis.diseases.length > 0 && analysis.diseases[0]?.name !== 'None' && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              Detected Diseases
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.diseases.map((d, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/10">
                  <span className="font-medium text-foreground">{d.name}</span>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">Severity: {d.severity}</Badge>
                    <Badge variant="outline" className="text-xs">Area: {d.affectedArea}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Nutrient & Pest Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {analysis.nutrientDeficiency.length > 0 && (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <TrendingDown className="w-5 h-5 text-secondary" />
                Nutrient Deficiency
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {analysis.nutrientDeficiency.map((n, i) => (
                  <Badge key={i} variant="secondary">{n}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {analysis.pestIssues.length > 0 && analysis.pestIssues[0] !== 'None' && (
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Bug className="w-5 h-5 text-destructive" />
                Pest Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {analysis.pestIssues.map((p, i) => (
                  <Badge key={i} variant="destructive">{p}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Irrigation */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Droplets className="w-5 h-5 text-accent" />
            Irrigation Advice
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{analysis.irrigationAdvice}</p>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sprout className="w-5 h-5 text-primary" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.recommendations.map((r, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="text-muted-foreground text-sm">{r}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Preventive Measures */}
      {analysis.preventiveMeasures.length > 0 && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <ShieldCheck className="w-5 h-5 text-primary" />
              Preventive Measures
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.preventiveMeasures.map((m, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                  <span className="text-muted-foreground text-sm">{m}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
