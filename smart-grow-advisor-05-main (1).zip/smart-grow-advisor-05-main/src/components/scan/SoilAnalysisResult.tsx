import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FlaskConical, Droplets, Sprout, Layers, AlertTriangle, ShieldCheck } from 'lucide-react';

interface SoilAnalysis {
  soilType: string;
  condition: string;
  moisture: string;
  color: string;
  texture: string;
  organicMatter: string;
  issues: string[];
  recommendations: string[];
  suitableCrops: string[];
  fertilizerSuggestion: string;
  phEstimate: string;
  summary: string;
}

const conditionColors: Record<string, string> = {
  Excellent: 'bg-primary/10 text-primary border-primary/30',
  Good: 'bg-primary/10 text-primary border-primary/30',
  Fair: 'bg-secondary/10 text-secondary border-secondary/30',
  Poor: 'bg-destructive/10 text-destructive border-destructive/30',
};

export function SoilAnalysisResult({ analysis }: { analysis: SoilAnalysis }) {
  const condColor = conditionColors[analysis.condition] || conditionColors['Fair'];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Summary */}
      <Card className="glass-card overflow-hidden">
        <div className="h-1" style={{ background: 'linear-gradient(90deg, hsl(25 40% 35%), hsl(38 85% 55%), hsl(142 50% 28%))' }} />
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Layers className="w-6 h-6" style={{ color: 'hsl(25 40% 35%)' }} />
              {analysis.soilType}
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge className={condColor}>{analysis.condition}</Badge>
              <Badge variant="outline">pH: {analysis.phEstimate}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{analysis.summary}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Moisture</p>
              <p className="font-medium text-sm text-foreground">{analysis.moisture}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Color</p>
              <p className="font-medium text-sm text-foreground">{analysis.color}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Texture</p>
              <p className="font-medium text-sm text-foreground">{analysis.texture}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">Organic Matter</p>
              <p className="font-medium text-sm text-foreground">{analysis.organicMatter}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Issues */}
      {analysis.issues.length > 0 && analysis.issues[0] !== 'None' && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <AlertTriangle className="w-5 h-5 text-secondary" />
              Identified Issues
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {analysis.issues.map((issue, i) => (
                <li key={i} className="flex items-start gap-2 text-muted-foreground text-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                  {issue}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Fertilizer */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <FlaskConical className="w-5 h-5" style={{ color: 'hsl(25 40% 35%)' }} />
            Fertilizer Recommendation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{analysis.fertilizerSuggestion}</p>
        </CardContent>
      </Card>

      {/* Suitable Crops */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sprout className="w-5 h-5 text-primary" />
            Suitable Crops
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {analysis.suitableCrops.map((crop, i) => (
              <Badge key={i} variant="secondary" className="text-sm">{crop}</Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <ShieldCheck className="w-5 h-5 text-primary" />
            Improvement Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {analysis.recommendations.map((r, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {i + 1}
                </span>
                <span className="text-muted-foreground text-sm">{r}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
