// Mock crop data and prediction algorithms for demonstration
export const crops = [
  // ── Cereals & Grains ──────────────────────────────────────────────────────
  { id: 'rice', name: 'Rice', icon: '🌾', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 150, max: 300 }, category: 'Cereals & Grains' },
  { id: 'wheat', name: 'Wheat', icon: '🌾', optimalTemp: { min: 10, max: 25 }, optimalRain: { min: 50, max: 100 }, category: 'Cereals & Grains' },
  { id: 'maize', name: 'Maize (Corn)', icon: '🌾', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 60, max: 110 }, category: 'Cereals & Grains' },
  { id: 'barley', name: 'Barley', icon: '🌾', optimalTemp: { min: 12, max: 25 }, optimalRain: { min: 45, max: 90 }, category: 'Cereals & Grains' },
  { id: 'sorghum', name: 'Sorghum', icon: '🌾', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 40, max: 100 }, category: 'Cereals & Grains' },
  { id: 'millet', name: 'Pearl Millet (Bajra)', icon: '🌾', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 40, max: 80 }, category: 'Cereals & Grains' },
  { id: 'oats', name: 'Oats', icon: '🌾', optimalTemp: { min: 10, max: 22 }, optimalRain: { min: 50, max: 100 }, category: 'Cereals & Grains' },
  { id: 'ragi', name: 'Finger Millet (Ragi)', icon: '🌾', optimalTemp: { min: 15, max: 30 }, optimalRain: { min: 50, max: 100 }, category: 'Cereals & Grains' },
  { id: 'jowar', name: 'Jowar (Sorghum)', icon: '🌾', optimalTemp: { min: 25, max: 35 }, optimalRain: { min: 40, max: 100 }, category: 'Cereals & Grains' },
  { id: 'bajra', name: 'Bajra', icon: '🌾', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 30, max: 80 }, category: 'Cereals & Grains' },
  { id: 'foxtail_millet', name: 'Foxtail Millet (Kangni)', icon: '🌾', optimalTemp: { min: 20, max: 33 }, optimalRain: { min: 35, max: 80 }, category: 'Cereals & Grains' },
  { id: 'kodo_millet', name: 'Kodo Millet', icon: '🌾', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 40, max: 90 }, category: 'Cereals & Grains' },
  { id: 'proso_millet', name: 'Proso Millet (Cheena)', icon: '🌾', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 30, max: 70 }, category: 'Cereals & Grains' },
  { id: 'little_millet', name: 'Little Millet (Kutki)', icon: '🌾', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 35, max: 80 }, category: 'Cereals & Grains' },
  { id: 'barnyard_millet', name: 'Barnyard Millet (Jhangora)', icon: '🌾', optimalTemp: { min: 20, max: 33 }, optimalRain: { min: 40, max: 90 }, category: 'Cereals & Grains' },

  // ── Pulses & Legumes ──────────────────────────────────────────────────────
  { id: 'soybean', name: 'Soybean', icon: '🫛', optimalTemp: { min: 20, max: 30 }, optimalRain: { min: 60, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'chickpea', name: 'Chickpea (Chana)', icon: '🫛', optimalTemp: { min: 15, max: 30 }, optimalRain: { min: 40, max: 80 }, category: 'Pulses & Legumes' },
  { id: 'lentil', name: 'Lentil (Masoor)', icon: '🫛', optimalTemp: { min: 15, max: 25 }, optimalRain: { min: 30, max: 70 }, category: 'Pulses & Legumes' },
  { id: 'blackgram', name: 'Black Gram (Urad Dal)', icon: '🫛', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 60, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'greengram', name: 'Green Gram (Moong Dal)', icon: '🫘', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 60, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'pigeonpea', name: 'Pigeon Pea (Tur/Arhar Dal)', icon: '🫘', optimalTemp: { min: 18, max: 35 }, optimalRain: { min: 60, max: 150 }, category: 'Pulses & Legumes' },
  { id: 'kidney_bean', name: 'Kidney Bean (Rajma)', icon: '🫘', optimalTemp: { min: 15, max: 25 }, optimalRain: { min: 50, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'pea', name: 'Field Pea (Matar)', icon: '🫘', optimalTemp: { min: 10, max: 22 }, optimalRain: { min: 40, max: 80 }, category: 'Pulses & Legumes' },
  { id: 'groundnut', name: 'Groundnut (Peanut)', icon: '🥜', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 50, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'cowpea', name: 'Cowpea (Lobia)', icon: '🫘', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 40, max: 80 }, category: 'Pulses & Legumes' },
  { id: 'moth_bean', name: 'Moth Bean (Matki)', icon: '🫘', optimalTemp: { min: 24, max: 38 }, optimalRain: { min: 30, max: 70 }, category: 'Pulses & Legumes' },
  { id: 'horse_gram', name: 'Horse Gram (Kulthi)', icon: '🫘', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 50, max: 100 }, category: 'Pulses & Legumes' },
  { id: 'dolichos_bean', name: 'Dolichos Bean (Val)', icon: '🫘', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 60, max: 120 }, category: 'Pulses & Legumes' },

  // ── Cash Crops & Oilseeds ──────────────────────────────────────────────────
  { id: 'cotton', name: 'Cotton', icon: '🌱', optimalTemp: { min: 21, max: 35 }, optimalRain: { min: 50, max: 100 }, category: 'Cash Crops & Oilseeds' },
  { id: 'sugarcane', name: 'Sugarcane', icon: '🎋', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 150, max: 250 }, category: 'Cash Crops & Oilseeds' },
  { id: 'jute', name: 'Jute', icon: '🌿', optimalTemp: { min: 24, max: 37 }, optimalRain: { min: 150, max: 300 }, category: 'Cash Crops & Oilseeds' },
  { id: 'tobacco', name: 'Tobacco', icon: '🌿', optimalTemp: { min: 20, max: 30 }, optimalRain: { min: 50, max: 100 }, category: 'Cash Crops & Oilseeds' },
  { id: 'sunflower', name: 'Sunflower', icon: '🌻', optimalTemp: { min: 18, max: 35 }, optimalRain: { min: 50, max: 100 }, category: 'Cash Crops & Oilseeds' },
  { id: 'mustard', name: 'Mustard (Sarson)', icon: '🌼', optimalTemp: { min: 10, max: 25 }, optimalRain: { min: 30, max: 70 }, category: 'Cash Crops & Oilseeds' },
  { id: 'sesame', name: 'Sesame (Til)', icon: '🌿', optimalTemp: { min: 25, max: 37 }, optimalRain: { min: 40, max: 80 }, category: 'Cash Crops & Oilseeds' },
  { id: 'linseed', name: 'Linseed (Alsi)', icon: '🌸', optimalTemp: { min: 10, max: 22 }, optimalRain: { min: 40, max: 80 }, category: 'Cash Crops & Oilseeds' },
  { id: 'castor', name: 'Castor (Arandi)', icon: '🌿', optimalTemp: { min: 20, max: 40 }, optimalRain: { min: 50, max: 100 }, category: 'Cash Crops & Oilseeds' },
  { id: 'rapeseed', name: 'Rapeseed (Toria)', icon: '🌼', optimalTemp: { min: 10, max: 25 }, optimalRain: { min: 30, max: 70 }, category: 'Cash Crops & Oilseeds' },
  { id: 'safflower', name: 'Safflower (Kusum)', icon: '🌼', optimalTemp: { min: 15, max: 35 }, optimalRain: { min: 30, max: 80 }, category: 'Cash Crops & Oilseeds' },
  { id: 'niger', name: 'Niger Seed (Ramtil)', icon: '🌿', optimalTemp: { min: 18, max: 30 }, optimalRain: { min: 75, max: 150 }, category: 'Cash Crops & Oilseeds' },
  { id: 'hemp', name: 'Hemp (Sann Hemp)', icon: '🌿', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 60, max: 120 }, category: 'Cash Crops & Oilseeds' },

  // ── Plantation Crops ──────────────────────────────────────────────────────
  { id: 'tea', name: 'Tea', icon: '🍵', optimalTemp: { min: 18, max: 30 }, optimalRain: { min: 150, max: 300 }, category: 'Plantation Crops' },
  { id: 'coffee', name: 'Coffee', icon: '☕', optimalTemp: { min: 18, max: 28 }, optimalRain: { min: 150, max: 250 }, category: 'Plantation Crops' },
  { id: 'rubber', name: 'Rubber', icon: '🌳', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 200, max: 400 }, category: 'Plantation Crops' },
  { id: 'cashew', name: 'Cashew', icon: '🥜', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 75, max: 150 }, category: 'Plantation Crops' },
  { id: 'arecanut', name: 'Arecanut (Supari)', icon: '🌴', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 150, max: 300 }, category: 'Plantation Crops' },
  { id: 'oil_palm', name: 'Oil Palm', icon: '🌴', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 200, max: 350 }, category: 'Plantation Crops' },
  { id: 'cocoa', name: 'Cocoa', icon: '🌱', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 150, max: 300 }, category: 'Plantation Crops' },
  { id: 'vanilla', name: 'Vanilla', icon: '🌿', optimalTemp: { min: 20, max: 30 }, optimalRain: { min: 150, max: 250 }, category: 'Plantation Crops' },
  { id: 'coconut', name: 'Coconut', icon: '🥥', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 150, max: 300 }, category: 'Plantation Crops' },

  // ── Spices & Herbs ────────────────────────────────────────────────────────
  { id: 'turmeric', name: 'Turmeric (Haldi)', icon: '🟡', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Spices & Herbs' },
  { id: 'ginger', name: 'Ginger (Adrak)', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Spices & Herbs' },
  { id: 'pepper', name: 'Black Pepper (Kali Mirch)', icon: '⚫', optimalTemp: { min: 18, max: 32 }, optimalRain: { min: 150, max: 250 }, category: 'Spices & Herbs' },
  { id: 'cardamom', name: 'Cardamom (Elaichi)', icon: '🌿', optimalTemp: { min: 15, max: 25 }, optimalRain: { min: 150, max: 250 }, category: 'Spices & Herbs' },
  { id: 'clove', name: 'Clove (Laung)', icon: '🌿', optimalTemp: { min: 20, max: 30 }, optimalRain: { min: 150, max: 250 }, category: 'Spices & Herbs' },
  { id: 'coriander', name: 'Coriander (Dhaniya)', icon: '🌿', optimalTemp: { min: 17, max: 28 }, optimalRain: { min: 30, max: 70 }, category: 'Spices & Herbs' },
  { id: 'cumin', name: 'Cumin (Jeera)', icon: '🟤', optimalTemp: { min: 20, max: 32 }, optimalRain: { min: 25, max: 60 }, category: 'Spices & Herbs' },
  { id: 'fennel', name: 'Fennel (Saunf)', icon: '🌿', optimalTemp: { min: 15, max: 28 }, optimalRain: { min: 30, max: 70 }, category: 'Spices & Herbs' },
  { id: 'fenugreek', name: 'Fenugreek (Methi)', icon: '🌿', optimalTemp: { min: 10, max: 28 }, optimalRain: { min: 30, max: 70 }, category: 'Spices & Herbs' },
  { id: 'ajwain', name: 'Ajwain (Carom Seeds)', icon: '🌿', optimalTemp: { min: 15, max: 30 }, optimalRain: { min: 25, max: 60 }, category: 'Spices & Herbs' },
  { id: 'mint', name: 'Mint (Pudina)', icon: '🌿', optimalTemp: { min: 15, max: 30 }, optimalRain: { min: 60, max: 120 }, category: 'Spices & Herbs' },
  { id: 'basil', name: 'Basil (Tulsi)', icon: '🌿', optimalTemp: { min: 18, max: 30 }, optimalRain: { min: 40, max: 80 }, category: 'Spices & Herbs' },
  { id: 'lemongrass', name: 'Lemongrass', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 60, max: 120 }, category: 'Spices & Herbs' },
  { id: 'nutmeg', name: 'Nutmeg (Jaiphal)', icon: '🌿', optimalTemp: { min: 22, max: 32 }, optimalRain: { min: 150, max: 250 }, category: 'Spices & Herbs' },
  { id: 'cinnamon', name: 'Cinnamon (Dalchini)', icon: '🌿', optimalTemp: { min: 20, max: 30 }, optimalRain: { min: 100, max: 200 }, category: 'Spices & Herbs' },
  { id: 'star_anise', name: 'Star Anise', icon: '🌿', optimalTemp: { min: 15, max: 25 }, optimalRain: { min: 100, max: 200 }, category: 'Spices & Herbs' },
  { id: 'bay_leaf', name: 'Bay Leaf (Tejpatta)', icon: '🌿', optimalTemp: { min: 10, max: 25 }, optimalRain: { min: 60, max: 120 }, category: 'Spices & Herbs' },
  { id: 'saffron', name: 'Saffron (Kesar)', icon: '🟡', optimalTemp: { min: 10, max: 20 }, optimalRain: { min: 25, max: 50 }, category: 'Spices & Herbs' },

  // ── Roots & Tubers ────────────────────────────────────────────────────────
  { id: 'cassava', name: 'Cassava (Tapioca)', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Roots & Tubers' },
  { id: 'yam', name: 'Yam (Suran)', icon: '🌿', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Roots & Tubers' },
  { id: 'guar', name: 'Guar (Cluster Bean)', icon: '🫘', optimalTemp: { min: 25, max: 40 }, optimalRain: { min: 30, max: 80 }, category: 'Roots & Tubers' },
  { id: 'arrowroot', name: 'Arrowroot (Arararoot)', icon: '🌿', optimalTemp: { min: 20, max: 32 }, optimalRain: { min: 100, max: 200 }, category: 'Roots & Tubers' },
  { id: 'colocasia', name: 'Colocasia (Arbi)', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Roots & Tubers' },
  { id: 'lotus_rhizome', name: 'Lotus Rhizome (Kamal Kakdi)', icon: '🌸', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Roots & Tubers' },

  // ── Fodder & Green Manure ─────────────────────────────────────────────────
  { id: 'berseem', name: 'Berseem (Egyptian Clover)', icon: '🌿', optimalTemp: { min: 10, max: 25 }, optimalRain: { min: 40, max: 100 }, category: 'Fodder & Green Manure' },
  { id: 'lucerne', name: 'Lucerne (Alfalfa)', icon: '🌿', optimalTemp: { min: 15, max: 30 }, optimalRain: { min: 40, max: 100 }, category: 'Fodder & Green Manure' },
  { id: 'napier_grass', name: 'Napier Grass', icon: '🌿', optimalTemp: { min: 22, max: 35 }, optimalRain: { min: 100, max: 200 }, category: 'Fodder & Green Manure' },
  { id: 'sudan_grass', name: 'Sudan Grass', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 50, max: 120 }, category: 'Fodder & Green Manure' },
  { id: 'sesbania', name: 'Sesbania (Dhaincha)', icon: '🌿', optimalTemp: { min: 20, max: 35 }, optimalRain: { min: 60, max: 150 }, category: 'Fodder & Green Manure' },
];

export const seasons = [
  { id: 'kharif', name: 'Kharif (Monsoon)', months: 'June - October' },
  { id: 'rabi', name: 'Rabi (Winter)', months: 'October - March' },
  { id: 'zaid', name: 'Zaid (Summer)', months: 'March - June' },
  { id: 'rainy', name: 'Rainy Season', months: 'June - September' },
];

export const soilTypes = [
  { id: 'alluvial', name: 'Alluvial Soil', description: 'Rich in potash, ideal for most crops' },
  { id: 'black', name: 'Black Soil', description: 'High moisture retention, good for cotton' },
  { id: 'red', name: 'Red Soil', description: 'Good for groundnut, millets' },
  { id: 'laterite', name: 'Laterite Soil', description: 'Suitable for tea, coffee, cashew' },
  { id: 'sandy', name: 'Sandy Soil', description: 'Good drainage, needs fertilizers' },
];

export interface PredictionInput {
  crop: string;
  season: string;
  soilType: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  ph: number;
  rainfall: number;
  temperature: number;
  humidity: number;
  area: number;
}

export interface PredictionResult {
  yieldPrediction: number;
  confidence: number;
  unit: string;
  modelUsed: string;
  factors: {
    name: string;
    impact: 'positive' | 'negative' | 'neutral';
    score: number;
  }[];
  recommendations: string[];
  optimalFertilizer: {
    nitrogen: number;
    phosphorus: number;
    potassium: number;
  };
  irrigationSchedule: string[];
  bestHarvestTime: string;
}

// Simulated ML prediction (weighted algorithm)
export function predictYield(input: PredictionInput): PredictionResult {
  const crop = crops.find(c => c.id === input.crop);
  if (!crop) throw new Error('Invalid crop');

  // Base yield calculations (tons/hectare)
  const baseYields: Record<string, number> = {
    // Cereals & Grains
    rice: 4.5, wheat: 3.2, maize: 5.8, barley: 2.8, sorghum: 3.0, millet: 2.5,
    oats: 2.6, ragi: 2.0, jowar: 2.8, bajra: 2.4,
    foxtail_millet: 2.0, kodo_millet: 1.8, proso_millet: 2.2, little_millet: 1.8, barnyard_millet: 2.0,
    // Pulses & Legumes
    soybean: 2.5, chickpea: 1.8, lentil: 1.5, blackgram: 1.2, greengram: 1.3,
    pigeonpea: 1.5, kidney_bean: 1.8, pea: 2.0, groundnut: 2.2, cowpea: 1.2,
    moth_bean: 0.8, horse_gram: 0.9, dolichos_bean: 1.5,
    // Cash Crops & Oilseeds
    cotton: 1.8, sugarcane: 70, jute: 2.5, tobacco: 2.0, sunflower: 1.8,
    mustard: 1.5, sesame: 0.8, linseed: 1.2, castor: 1.5,
    rapeseed: 1.4, safflower: 1.0, niger: 0.6, hemp: 2.0,
    // Plantation Crops
    tea: 2.0, coffee: 1.5, rubber: 1.2, cashew: 1.5, arecanut: 4.0,
    oil_palm: 20, cocoa: 1.0, vanilla: 0.5, coconut: 8.0,
    // Spices & Herbs
    turmeric: 5, ginger: 8, pepper: 2, cardamom: 0.5, clove: 1.5, coriander: 1.2,
    cumin: 0.8, fennel: 1.5, fenugreek: 1.0, ajwain: 0.8, mint: 5, basil: 3, lemongrass: 8,
    nutmeg: 0.8, cinnamon: 2.0, star_anise: 1.0, bay_leaf: 1.5, saffron: 0.006,
    // Roots & Tubers
    cassava: 20, yam: 12, guar: 1.5, arrowroot: 8, colocasia: 10, lotus_rhizome: 8,
    // Fodder & Green Manure
    berseem: 40, lucerne: 35, napier_grass: 80, sudan_grass: 50, sesbania: 20,
  };

  let yieldScore = baseYields[input.crop] || 3.0;
  const factors: PredictionResult['factors'] = [];

  // Temperature impact
  const tempOptimal = (crop.optimalTemp.min + crop.optimalTemp.max) / 2;
  const tempDiff = Math.abs(input.temperature - tempOptimal);
  const tempScore = Math.max(0, 100 - tempDiff * 4);
  yieldScore *= (0.7 + (tempScore / 100) * 0.4);
  factors.push({
    name: 'Temperature',
    impact: tempScore > 70 ? 'positive' : tempScore > 40 ? 'neutral' : 'negative',
    score: tempScore
  });

  // Rainfall impact
  const rainOptimal = (crop.optimalRain.min + crop.optimalRain.max) / 2;
  const rainDiff = Math.abs(input.rainfall - rainOptimal);
  const rainScore = Math.max(0, 100 - (rainDiff / rainOptimal) * 50);
  yieldScore *= (0.7 + (rainScore / 100) * 0.4);
  factors.push({
    name: 'Rainfall',
    impact: rainScore > 70 ? 'positive' : rainScore > 40 ? 'neutral' : 'negative',
    score: rainScore
  });

  // Soil pH impact (optimal 6.0-7.5)
  const phScore = input.ph >= 6.0 && input.ph <= 7.5 ? 90 : 
                  input.ph >= 5.5 && input.ph <= 8.0 ? 70 : 50;
  yieldScore *= (0.8 + (phScore / 100) * 0.25);
  factors.push({
    name: 'Soil pH',
    impact: phScore > 80 ? 'positive' : phScore > 60 ? 'neutral' : 'negative',
    score: phScore
  });

  // NPK impact
  const npkBalance = (input.nitrogen + input.phosphorus + input.potassium) / 3;
  const npkScore = Math.min(100, npkBalance * 2);
  yieldScore *= (0.75 + (npkScore / 100) * 0.35);
  factors.push({
    name: 'NPK Balance',
    impact: npkScore > 70 ? 'positive' : npkScore > 40 ? 'neutral' : 'negative',
    score: npkScore
  });

  // Humidity impact
  const humidityScore = input.humidity >= 50 && input.humidity <= 80 ? 85 : 65;
  yieldScore *= (0.85 + (humidityScore / 100) * 0.2);
  factors.push({
    name: 'Humidity',
    impact: humidityScore > 75 ? 'positive' : 'neutral',
    score: humidityScore
  });

  // Calculate total yield
  const totalYield = yieldScore * input.area;
  const avgScore = factors.reduce((sum, f) => sum + f.score, 0) / factors.length;
  const confidence = Math.min(95, 60 + avgScore * 0.35);

  // Generate recommendations
  const recommendations: string[] = [];
  if (tempScore < 60) recommendations.push(`Consider greenhouse cultivation for optimal temperature control`);
  if (rainScore < 60) recommendations.push(`Implement drip irrigation to supplement rainfall`);
  if (phScore < 70) recommendations.push(`Apply lime or sulfur to adjust soil pH to 6.0-7.5 range`);
  if (npkScore < 60) recommendations.push(`Increase fertilizer application for better nutrient balance`);
  if (recommendations.length === 0) recommendations.push(`Current conditions are optimal for ${crop.name} cultivation`);

  // Optimal fertilizer calculation
  const optimalN = Math.max(40, 120 - input.nitrogen);
  const optimalP = Math.max(20, 60 - input.phosphorus);
  const optimalK = Math.max(30, 80 - input.potassium);

  // Irrigation schedule
  const irrigationSchedule = input.rainfall < 100 
    ? ['Week 1-2: Daily irrigation (30mm)', 'Week 3-4: Alternate day irrigation (25mm)', 'Week 5+: Weekly irrigation (40mm)']
    : ['Week 1-2: Twice weekly (20mm)', 'Week 3+: Weekly irrigation based on soil moisture'];

  // Harvest time
  const harvestTimes: Record<string, string> = {
    // Cereals & Grains
    rice: '120-150 days after sowing (Oct-Nov)', wheat: '110-130 days after sowing (Mar-Apr)',
    maize: '90-120 days after sowing', barley: '90-120 days after sowing',
    sorghum: '90-120 days after sowing', millet: '70-90 days after sowing',
    oats: '80-100 days after sowing', ragi: '90-120 days after sowing',
    jowar: '90-120 days after sowing', bajra: '70-90 days after sowing',
    foxtail_millet: '75-90 days after sowing', kodo_millet: '100-135 days after sowing',
    proso_millet: '60-80 days after sowing', little_millet: '75-90 days after sowing',
    barnyard_millet: '45-65 days after sowing',
    // Pulses & Legumes
    soybean: '85-120 days after sowing', chickpea: '90-120 days after sowing',
    lentil: '80-110 days after sowing', blackgram: '60-90 days after sowing',
    greengram: '60-90 days after sowing', pigeonpea: '150-180 days after sowing',
    kidney_bean: '90-120 days after sowing', pea: '60-90 days after sowing',
    groundnut: '90-120 days after sowing', cowpea: '60-90 days after sowing',
    moth_bean: '60-90 days after sowing', horse_gram: '90-120 days after sowing',
    dolichos_bean: '90-120 days after sowing',
    // Cash Crops & Oilseeds
    cotton: '150-180 days after sowing', sugarcane: '12-18 months after planting',
    jute: '90-120 days after sowing', tobacco: '60-90 days after transplant',
    sunflower: '80-120 days after sowing', mustard: '90-110 days after sowing',
    sesame: '80-100 days after sowing', linseed: '90-120 days after sowing',
    castor: '150-180 days after sowing', rapeseed: '90-110 days after sowing',
    safflower: '120-150 days after sowing', niger: '90-120 days after sowing',
    hemp: '70-90 days after sowing',
    // Plantation Crops
    tea: 'Perennial; harvest Mar-Nov', coffee: 'Perennial; harvest Nov-Jan',
    rubber: 'Perennial; tapping begins after 5 years', cashew: 'Perennial; harvest Mar-May',
    arecanut: 'Perennial; harvest Nov-Feb', oil_palm: 'Perennial; harvest year-round',
    cocoa: 'Perennial; harvest Oct-Mar', vanilla: 'Perennial; harvest after 3 years',
    coconut: 'Perennial; harvest year-round',
    // Spices & Herbs
    turmeric: '8-9 months after planting', ginger: '8-9 months after planting',
    pepper: 'Perennial; harvest Nov-Jan', cardamom: 'Perennial; harvest Aug-Oct',
    clove: 'Perennial; harvest Sep-Dec', coriander: '45-90 days after sowing',
    cumin: '90-120 days after sowing', fennel: '90-120 days after sowing',
    fenugreek: '90-120 days after sowing', ajwain: '90-120 days after sowing',
    mint: '70-100 days after planting', basil: '45-60 days after planting',
    lemongrass: '6-8 months after planting', nutmeg: 'Perennial; harvest year-round',
    cinnamon: 'Perennial; bark harvested every 2 years', star_anise: 'Perennial; harvest Oct-Nov',
    bay_leaf: 'Perennial; harvest year-round', saffron: '15-20 days after flowering (Oct-Nov)',
    // Roots & Tubers
    cassava: '9-12 months after planting', yam: '6-10 months after planting',
    guar: '90-120 days after sowing', arrowroot: '10-12 months after planting',
    colocasia: '150-180 days after planting', lotus_rhizome: '6-8 months after planting',
    // Fodder & Green Manure
    berseem: '45-60 days for first cut; perennial', lucerne: '60-70 days; 4-6 cuts/year',
    napier_grass: '60-75 days for first cut; perennial', sudan_grass: '45-60 days after sowing',
    sesbania: '45-60 days for green manure',
  };

  return {
    yieldPrediction: Math.round(totalYield * 100) / 100,
    confidence: Math.round(confidence * 10) / 10,
    unit: 'tons',
    modelUsed: 'Gradient Boosting (XGBoost)',
    factors,
    recommendations,
    optimalFertilizer: { nitrogen: optimalN, phosphorus: optimalP, potassium: optimalK },
    irrigationSchedule,
    bestHarvestTime: harvestTimes[input.crop] || '90-120 days after sowing'
  };
}

// Model comparison data for analytics
export const modelComparison = [
  { name: 'Linear Regression', rmse: 2.34, mae: 1.89, r2: 0.78, accuracy: 78 },
  { name: 'Random Forest', rmse: 1.56, mae: 1.23, r2: 0.89, accuracy: 89 },
  { name: 'XGBoost', rmse: 1.21, mae: 0.98, r2: 0.94, accuracy: 94 },
  { name: 'Neural Network', rmse: 1.45, mae: 1.12, r2: 0.91, accuracy: 91 },
];

// Historical yield data for visualization
export const historicalYields = [
  { year: 2019, rice: 4.2, wheat: 3.1, maize: 5.4, cotton: 1.6 },
  { year: 2020, rice: 4.4, wheat: 3.3, maize: 5.6, cotton: 1.7 },
  { year: 2021, rice: 4.3, wheat: 3.0, maize: 5.5, cotton: 1.5 },
  { year: 2022, rice: 4.6, wheat: 3.4, maize: 5.8, cotton: 1.8 },
  { year: 2023, rice: 4.8, wheat: 3.5, maize: 6.0, cotton: 1.9 },
  { year: 2024, rice: 5.0, wheat: 3.6, maize: 6.2, cotton: 2.0 },
];

// Crop recommendation based on conditions
export function recommendCrop(input: Partial<PredictionInput>): typeof crops[0][] {
  return crops.map(crop => {
    let score = 50;
    
    if (input.temperature) {
      const inRange = input.temperature >= crop.optimalTemp.min && input.temperature <= crop.optimalTemp.max;
      score += inRange ? 25 : -15;
    }
    
    if (input.rainfall) {
      const inRange = input.rainfall >= crop.optimalRain.min && input.rainfall <= crop.optimalRain.max;
      score += inRange ? 25 : -15;
    }
    
    return { ...crop, score };
  }).sort((a, b) => (b as any).score - (a as any).score);
}
