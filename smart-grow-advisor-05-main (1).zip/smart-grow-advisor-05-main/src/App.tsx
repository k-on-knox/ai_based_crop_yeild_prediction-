import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { BackgroundSlideshow } from "@/components/layout/BackgroundSlideshow";
import { FarmerChatbot } from "@/components/chat/FarmerChatbot";
import Index from "./pages/Index";
import Predict from "./pages/Predict";
import Recommend from "./pages/Recommend";
import Analytics from "./pages/Analytics";
import Scan from "./pages/Scan";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <BackgroundSlideshow />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/predict" element={<Predict />} />
          <Route path="/recommend" element={<Recommend />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/scan" element={<Scan />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        <FarmerChatbot />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
