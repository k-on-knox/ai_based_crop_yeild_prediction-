import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { PredictionForm } from '@/components/predict/PredictionForm';
import { PredictionResultCard } from '@/components/predict/PredictionResult';
import { predictYield, type PredictionInput, type PredictionResult } from '@/lib/mockData';
import { BarChart3 } from 'lucide-react';

const Predict = () => {
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [input, setInput] = useState<PredictionInput | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handlePredict = async (data: PredictionInput) => {
    setIsLoading(true);
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    try {
      const prediction = predictYield(data);
      setInput(data);
      setResult(prediction);
    } catch (error) {
      console.error('Prediction error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <Header />
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm text-white text-sm font-medium mb-4">
              <BarChart3 className="w-4 h-4" />
              ML-Powered Prediction
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold text-white drop-shadow-lg mb-3">
              Crop Yield Prediction
            </h1>
            <p className="text-white/80 drop-shadow max-w-2xl mx-auto">
              Enter your soil parameters, weather conditions, and crop details to get accurate 
              yield predictions powered by XGBoost machine learning model.
            </p>
          </div>

          {/* Main Content */}
          <div className="max-w-4xl mx-auto">
            {!result ? (
              <PredictionForm onSubmit={handlePredict} isLoading={isLoading} />
            ) : (
              <div className="space-y-6">
                <button
                  onClick={() => { setResult(null); setInput(null); }}
                  className="text-primary hover:underline text-sm font-medium"
                >
                  ← Make New Prediction
                </button>
                {input && <PredictionResultCard result={result} input={input} />}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Predict;
