import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Hero } from '@/components/home/Hero';
import { Features } from '@/components/home/Features';
import { TechStack } from '@/components/home/TechStack';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <Header />
      <main className="flex-1 pt-16">
        <Hero />
        <Features />
        <TechStack />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
