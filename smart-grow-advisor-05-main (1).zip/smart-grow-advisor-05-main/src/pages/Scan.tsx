import { useState } from 'react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { PhotoCapture } from '@/components/scan/PhotoCapture';
import { CropAnalysisResult } from '@/components/scan/CropAnalysisResult';
import { SoilAnalysisResult } from '@/components/scan/SoilAnalysisResult';
import { Camera, Leaf, Layers } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

type AnalysisType = 'crop' | 'soil';

const Scan = () => {
  const [analysisType, setAnalysisType] = useState<AnalysisType>('crop');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleCapture = async (imageBase64: string) => {
    setIsAnalyzing(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('analyze-crop', {
        body: { imageBase64, analysisType },
      });

      if (error) {
        console.error('Analysis error:', error);
        toast.error(error.message || 'Failed to analyze image. Please try again.');
        return;
      }

      if (data?.error) {
        toast.error(data.error);
        return;
      }

      setResult(data.analysis);
      toast.success('Analysis complete!');
    } catch (err) {
      console.error('Unexpected error:', err);
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleNewScan = () => {
    setResult(null);
  };

  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <Header />
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm text-white text-sm font-medium mb-4">
              <Camera className="w-4 h-4" />
              AI-Powered Photo Analysis
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold text-white drop-shadow-lg mb-3">
              Scan & Analyze
            </h1>
            <p className="text-white/80 drop-shadow max-w-2xl mx-auto">
              Take a photo of your crop or soil and get instant AI-powered analysis with
              disease detection, nutrient assessment, and actionable recommendations.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-8">
            {/* Analysis Type Selector */}
            {!result && (
              <div className="flex justify-center gap-3">
                <Button
                  variant={analysisType === 'crop' ? 'default' : 'outline'}
                  onClick={() => setAnalysisType('crop')}
                  className={cn('gap-2', analysisType === 'crop' && 'shadow-md')}
                  disabled={isAnalyzing}
                >
                  <Leaf className="w-4 h-4" />
                  Crop Health
                </Button>
                <Button
                  variant={analysisType === 'soil' ? 'default' : 'outline'}
                  onClick={() => setAnalysisType('soil')}
                  className={cn('gap-2', analysisType === 'soil' && 'shadow-md')}
                  disabled={isAnalyzing}
                >
                  <Layers className="w-4 h-4" />
                  Soil Analysis
                </Button>
              </div>
            )}

            {/* Camera / Upload */}
            {!result && (
              <PhotoCapture onCapture={handleCapture} isAnalyzing={isAnalyzing} />
            )}

            {/* Results */}
            {result && (
              <div className="space-y-6">
                <button
                  onClick={handleNewScan}
                  className="text-primary hover:underline text-sm font-medium"
                >
                  ← New Scan
                </button>
                {analysisType === 'crop' ? (
                  <CropAnalysisResult analysis={result} />
                ) : (
                  <SoilAnalysisResult analysis={result} />
                )}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Scan;
