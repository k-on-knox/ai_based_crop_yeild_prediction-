import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { ModelComparison } from '@/components/analytics/ModelComparison';
import { YieldTrends } from '@/components/analytics/YieldTrends';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Brain, TrendingUp } from 'lucide-react';

const Analytics = () => {
  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <Header />
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm text-white text-sm font-medium mb-4">
              <BookOpen className="w-4 h-4" />
              Performance Analytics
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold text-white drop-shadow-lg mb-3">
              Analytics Dashboard
            </h1>
            <p className="text-white/80 drop-shadow max-w-2xl mx-auto">
              Comprehensive analysis of ML model performance, historical yield trends, 
              and prediction accuracy metrics.
            </p>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="models" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
              <TabsTrigger value="models" className="gap-2">
                <Brain className="w-4 h-4" />
                Model Comparison
              </TabsTrigger>
              <TabsTrigger value="trends" className="gap-2">
                <TrendingUp className="w-4 h-4" />
                Yield Trends
              </TabsTrigger>
            </TabsList>

            <TabsContent value="models" className="animate-fade-in">
              <ModelComparison />
            </TabsContent>

            <TabsContent value="trends" className="animate-fade-in">
              <YieldTrends />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Analytics;
