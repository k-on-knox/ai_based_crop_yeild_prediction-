import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { CropRecommendation } from '@/components/recommend/CropRecommendation';
import { Lightbulb } from 'lucide-react';

const Recommend = () => {
  return (
    <div className="min-h-screen flex flex-col relative z-10">
      <Header />
      <main className="flex-1 pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm text-white text-sm font-medium mb-4">
              <Lightbulb className="w-4 h-4" />
              AI Recommendations
            </div>
            <h1 className="font-display text-3xl md:text-4xl font-bold text-white drop-shadow-lg mb-3">
              Crop Recommendations
            </h1>
            <p className="text-white/80 drop-shadow max-w-2xl mx-auto">
              Get AI-powered suggestions for the best crops to grow based on your 
              climate conditions and soil characteristics.
            </p>
          </div>

          {/* Recommendation Engine */}
          <CropRecommendation />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Recommend;
